# Homework 4: Design Improvement of Static Website Generator

Find the assignment instructions at https://github.com/CMU-17-214/s2024/blob/main/assignments/hw4.md



For this assignment pick either Java or TypeScript by selecting with branch to work on. On the command line, check out the specific branch with `git checkout Java` or `git checkout TypeScript`. We will identify which branch you worked on based on the commit you submit on Canvas.
