---
name: hw4
about: issue template for design problems
title: "<Design Problem>"
labels: ''
assignees: ''

---

### Problem
<specific problem at specific location in code>

### Why Problematic
<explanation of why code is problematic>

<close this issue with description of fix and commits that contain the fix, including used design patterns (if any)>
